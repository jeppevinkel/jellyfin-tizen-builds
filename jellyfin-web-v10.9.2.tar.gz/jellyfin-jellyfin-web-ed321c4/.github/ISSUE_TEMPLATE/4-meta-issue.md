---
name: Meta Issue
about: You want to track a number of other issues as part of a larger project
labels: meta
---

* [ ] Issue 1 [#123]
* [ ] Issue 2 [#456]
* [ ] ...
